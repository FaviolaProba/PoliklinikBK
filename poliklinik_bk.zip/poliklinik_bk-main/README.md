# poliklinik_bk
Ini adalah tugas Minggu Pertama BK, Untuk plugins tidak bisa di upload disini, jadi di upload ke google drive, untuk linknya GD plugin ada di plugins.txt, setelah didownload masukkan ke folder poliklinik_bk.
