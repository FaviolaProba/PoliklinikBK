<div class="content-wrapper">
  <h1>Halaman Home Obat</h1>  
</div>